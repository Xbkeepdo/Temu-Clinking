package com.ch.clinking.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ch.clinking.entity.SaleInfo;
import com.ch.clinking.entity.UserSet;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface UserSetMapper extends BaseMapper<UserSet> {


}
