package com.ch.clinking.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ch.clinking.entity.SalesHistoryShopBrief;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface SalesHistoryShopBriefMapper extends BaseMapper<SalesHistoryShopBrief> {


}
