package com.ch.clinking.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ch.clinking.entity.Product;
import com.ch.clinking.entity.ProductDesigner;
import com.ch.clinking.entity.Result;
import com.ch.clinking.mapper.ProductDesignerMapper;
import com.ch.clinking.mapper.ProductMapper;
import com.ch.clinking.service.ProductDesignerService;
import com.ch.clinking.service.ProductService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("product")
public class ProductController {

    @Resource
    ProductService productService;

    @Resource
    ProductMapper productMapper;

    @Resource
    ProductDesignerService productDesignerService;

    @Resource
    ProductDesignerMapper productDesignerMapper;



    @GetMapping("/all")
    public Page<Product> getProducts(
            @RequestParam String shopId,
            @RequestParam("page") int page,      // 当前页，从 1 开始
            @RequestParam("size") int size,      // 每页显示数量
            @RequestParam(required = false) String searchKey, // 可选搜索关键词
            @RequestParam(required = false) String currentTab
    ) {
        // MyBatis Plus 的分页对象，page 从 1 开始，需要 -1 变成 0-based
        Page<Product> productPage = new Page<>(page, size);


        // 构造查询条件
        QueryWrapper<Product> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("shopId", shopId); // 根据 shopId 筛选

        // 根据 tab 参数筛选商品状态
        if (currentTab != null && !currentTab.equals("all")) {
            queryWrapper.eq("state", mapTabToState(currentTab)); // 根据 tab 映射状态
        }

        // 根据搜索关键字进行模糊搜索（可选）
        if (searchKey != null && !searchKey.trim().isEmpty()) {
            queryWrapper.and(wrapper -> wrapper.like("skcId", searchKey).or().like("title", searchKey));
        }



        // 查询分页数据
        return productService.page(productPage, queryWrapper);
    }

    @GetMapping("/allBindProducts")
    public Page<Product> getBindProducts(
            @RequestParam String nickName,
            @RequestParam String shopId,
            @RequestParam("page") int page,      // 当前页
            @RequestParam ("size")int size ,      // 每页显示多少条
             @RequestParam(required = false) String searchKey,// 可选搜索关键词
            @RequestParam(required = false) String currentTab
    ) {
        List<String> skcIds = productDesignerMapper.searchAllByDesigner(shopId,nickName);
        // 构造分页对象
        Page<Product> productPage = new Page<>(page, size);

        // 查询条件可以根据你的需要调整
        QueryWrapper<Product> queryWrapper = new QueryWrapper<>();


        // 如果 skcIds 为空，则跳过 IN 过滤
        if (skcIds == null || skcIds.isEmpty()) {
            // 可以选择根据其他条件查询，或者不添加 skcId 的筛选条件
            skcIds = Collections.singletonList("0");  // 用 "0" 或者 NULL 作为占位符
        }

            queryWrapper.in("skcId", skcIds); // 过滤 skcId




        // 根据 tab 参数筛选商品状态
        if (currentTab != null && !currentTab.equals("all")) {
            queryWrapper.eq("state", mapTabToState(currentTab)); // 根据 tab 映射状态
        }

        // 根据搜索关键字进行模糊搜索（可选）
        if (searchKey != null && !searchKey.trim().isEmpty()) {
            queryWrapper.and(wrapper -> wrapper.like("skcId", searchKey).or().like("title", searchKey));
        }
        // 查询并返回分页数据
        return productService.page(productPage, queryWrapper);
    }

//    @GetMapping("/all")
//    public ResponseEntity<List<Product>> getShopAllProducts(@RequestParam String shopId) {
//
//        // 构造分页对象
//        Page<Product> productPage = new Page<>(page, size);
//
//        // 查询条件可以根据你的需要调整
//        QueryWrapper<Product> queryWrapper = new QueryWrapper<>();
//        queryWrapper.eq("shop_id", shopId); // 过滤 shopId
//
//        return ResponseEntity.ok(productMapper.selectList(new QueryWrapper<Product>().eq("shopId",shopId)));
//    }

    @GetMapping("/search")
    public ResponseEntity<List<Product>> searchBySkcId(@RequestParam String skcId) {

        // 使用 MyBatis-Plus 的 QueryWrapper 实现模糊搜索
        QueryWrapper<Product> queryWrapper = new QueryWrapper<>();
        queryWrapper.like("skcId", skcId);

        // 返回符合条件的商品列表
        return ResponseEntity.ok(productService.list(queryWrapper));
    }


    @GetMapping("/getDesignerBind")
    public ResponseEntity<List<String>> getDesinerBindProduct(@RequestParam("shopId") String shopId,@RequestParam("nickName") String nickName){
    return ResponseEntity.ok(productDesignerMapper.searchAllByDesigner(shopId,nickName));
    }

    @PostMapping("/bind")
    public Result bindProductToDesigner(@RequestBody ProductDesigner productDesigner) {
        boolean success = productDesignerService.bindProduct(productDesigner);
        if (success) {
            return Result.success("绑定成功");
        } else {
            return Result.error(500, "绑定失败");
        }
    }

    // 解绑商品
    @PostMapping("/unbind")
    public Result unbindProductFromDesigner(@RequestBody ProductDesigner productDesigner) {
        boolean success = productDesignerService.unbindProduct(productDesigner);
        if (success) {
            return Result.success("解绑成功");
        } else {
            return Result.error(500, "解绑失败");
        }
    }

    // 查询是否绑定
    @GetMapping("/isBound")
    public Result checkIfBound(@RequestParam String skcId, @RequestParam String shopId, @RequestParam String name) {
        boolean isBound = productDesignerService.isProductBound(skcId, shopId, name);
        return Result.success(isBound);
    }



    // 根据 tab 值映射对应的状态
    private String mapTabToState(String tab) {
        Map<String, String> tabStateMap = new HashMap<>();
        tabStateMap.put("unpublished", "1");
        tabStateMap.put("pendingSample", "3");
        tabStateMap.put("reviewing", "5");
        tabStateMap.put("pricing", "7");
        tabStateMap.put("pendingOrder", "10");
        tabStateMap.put("published", "12");
        tabStateMap.put("terminated", "13");

        return tabStateMap.getOrDefault(tab, "all");
    }




}
