package com.ch.clinking.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.ch.clinking.entity.Cost;
import com.ch.clinking.entity.SalesHistory;
import org.springframework.transaction.annotation.Transactional;

@Transactional  // 使用事务管理
public interface SalesHistoryService extends IService<SalesHistory> {

    int getSalesCountByProduct(String skcId);
}
