package com.ch.clinking.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.ch.clinking.entity.Designer;
import com.ch.clinking.entity.Shop;

import java.util.List;

public interface DesignerService extends IService<Designer> {


}
