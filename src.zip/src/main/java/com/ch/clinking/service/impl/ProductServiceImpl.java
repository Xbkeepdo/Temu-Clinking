package com.ch.clinking.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ch.clinking.entity.Product;
import com.ch.clinking.entity.ProductDesigner;
import com.ch.clinking.mapper.ProductDesignerMapper;
import com.ch.clinking.mapper.ProductMapper;
import com.ch.clinking.service.ProductDesignerService;
import com.ch.clinking.service.ProductService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Map;

@Service("productService")
public class ProductServiceImpl extends ServiceImpl<ProductMapper, Product> implements ProductService {


    @Resource ProductMapper productMapper;



    @Override
    public boolean updateProductBySkcId(String skcId, UpdateWrapper updateWrapper) {

        if (productMapper.update(null, updateWrapper) > 0){
            return true;
        }
        else
            return false;

    }
}
