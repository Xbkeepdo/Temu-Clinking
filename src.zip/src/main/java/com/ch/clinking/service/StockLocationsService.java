package com.ch.clinking.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.ch.clinking.entity.Shop;
import com.ch.clinking.entity.StockLocations;

import java.util.List;

public interface StockLocationsService extends IService<StockLocations> {

}
