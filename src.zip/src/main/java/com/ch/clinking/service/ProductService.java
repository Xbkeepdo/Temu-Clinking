package com.ch.clinking.service;

import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.extension.service.IService;
import com.ch.clinking.entity.Product;
import com.ch.clinking.entity.ProductDesigner;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.Map;

public interface ProductService extends IService<Product> {



 @Transactional(propagation = Propagation.REQUIRES_NEW)
 boolean updateProductBySkcId(String skcId, UpdateWrapper updateWrapper);




}
