package com.ch.clinking.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ch.clinking.entity.Cost;
import com.ch.clinking.entity.SalesHistory;
import com.ch.clinking.mapper.CostMapper;
import com.ch.clinking.mapper.SalesHistoryMapper;
import com.ch.clinking.service.CostService;
import com.ch.clinking.service.SalesHistoryService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service("salesHistoryService")
public class SalesHistoryServiceImpl extends ServiceImpl<SalesHistoryMapper, SalesHistory> implements SalesHistoryService {

    @Resource
    SalesHistoryMapper salesHistoryMapper;
    @Override
    public int getSalesCountByProduct(String skcId) {

      return salesHistoryMapper.selectCountBySkcId(skcId);
    }
}
