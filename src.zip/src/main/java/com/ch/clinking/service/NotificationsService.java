package com.ch.clinking.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.ch.clinking.entity.Notifications;

public interface NotificationsService extends IService<Notifications> {


}
